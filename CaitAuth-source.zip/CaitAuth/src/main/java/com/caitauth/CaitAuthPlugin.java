package com.caitauth;

import com.caitauth.auth.AuthManager;
import com.caitauth.auth.PremiumVerifier;
import com.caitauth.auth.SessionManager;
import com.caitauth.commands.CaitAuthCommand;
import com.caitauth.commands.ChangePasswordCommand;
import com.caitauth.commands.LoginCommand;
import com.caitauth.commands.RegisterCommand;
import com.caitauth.commands.UnregisterCommand;
import com.caitauth.config.ConfigManager;
import com.caitauth.config.MessagesManager;
import com.caitauth.database.DatabaseManager;
import com.caitauth.integration.PlaceholderHook;
import com.caitauth.listeners.AsyncPreLoginListener;
import com.caitauth.listeners.ChatCommandGuardListener;
import com.caitauth.listeners.PlayerJoinQuitListener;
import com.caitauth.listeners.ProtectionListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;

public final class CaitAuthPlugin extends JavaPlugin {

    private ConfigManager configManager;
    private MessagesManager messagesManager;
    private DatabaseManager databaseManager;
    private SessionManager sessionManager;
    private PremiumVerifier premiumVerifier;
    private AuthManager authManager;

    @Override
    public void onEnable() {
        this.configManager = new ConfigManager(this);
        this.messagesManager = new MessagesManager(this);

        this.databaseManager = new DatabaseManager(this);
        try {
            databaseManager.connect();
        } catch (SQLException e) {
            getLogger().severe("Failed to connect to the database: " + e.getMessage());
            getLogger().severe("Disabling CaitAuth.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        this.sessionManager = new SessionManager(this);
        this.premiumVerifier = new PremiumVerifier(this);
        this.authManager = new AuthManager(this);

        registerListeners();
        registerCommands();
        registerIntegrations();

        getLogger().info("CaitAuth enabled — database: " + configManager.databaseType()
                + ", premium auto-detect: " + configManager.premiumAutoDetect());
    }

    @Override
    public void onDisable() {
        if (databaseManager != null) {
            databaseManager.shutdown();
        }
        getLogger().info("CaitAuth disabled.");
    }

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new AsyncPreLoginListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerJoinQuitListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ProtectionListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ChatCommandGuardListener(this), this);
    }

    private void registerCommands() {
        getCommand("register").setExecutor(new RegisterCommand(this));
        getCommand("login").setExecutor(new LoginCommand(this));
        getCommand("changepassword").setExecutor(new ChangePasswordCommand(this));
        getCommand("unregister").setExecutor(new UnregisterCommand(this));
        CaitAuthCommand caitAuthCommand = new CaitAuthCommand(this);
        getCommand("caitauth").setExecutor(caitAuthCommand);
        getCommand("caitauth").setTabCompleter(caitAuthCommand);
    }

    private void registerIntegrations() {
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new PlaceholderHook(this).register();
            getLogger().info("Hooked into PlaceholderAPI.");
        }
        if (Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) {
            getLogger().info("LuckPerms detected — permission nodes will be resolved through it automatically.");
        }
    }

    public void reload() {
        configManager.reload();
        messagesManager.reload();
    }

    public ConfigManager getConfigManager() { return configManager; }
    public MessagesManager getMessagesManager() { return messagesManager; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public SessionManager getSessionManager() { return sessionManager; }
    public PremiumVerifier getPremiumVerifier() { return premiumVerifier; }
    public AuthManager getAuthManager() { return authManager; }
}
