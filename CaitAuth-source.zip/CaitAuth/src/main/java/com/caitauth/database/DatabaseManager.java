package com.caitauth.database;

import com.caitauth.CaitAuthPlugin;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * All SQL in this class uses parameterized PreparedStatements exclusively —
 * no string concatenation of user input — to eliminate SQL injection risk.
 * All public methods are async: they return a CompletableFuture and run their
 * JDBC work on a dedicated background executor, never the server main thread.
 */
public final class DatabaseManager {

    public enum Type { SQLITE, MYSQL }

    private final CaitAuthPlugin plugin;
    private final Executor dbExecutor;
    private HikariDataSource dataSource;
    private Type type;

    public DatabaseManager(CaitAuthPlugin plugin) {
        this.plugin = plugin;
        // Bounded pool of worker threads dedicated to DB I/O so we never touch the main thread.
        this.dbExecutor = Executors.newFixedThreadPool(4, r -> {
            Thread t = new Thread(r, "CaitAuth-DB-Worker");
            t.setDaemon(true);
            return t;
        });
    }

    public void connect() throws SQLException {
        String configuredType = plugin.getConfigManager().databaseType();
        this.type = configuredType.equalsIgnoreCase("mysql") ? Type.MYSQL : Type.SQLITE;

        HikariConfig hikariConfig = new HikariConfig();

        if (type == Type.MYSQL) {
            String host = plugin.getConfigManager().mysqlHost();
            int port = plugin.getConfigManager().mysqlPort();
            String database = plugin.getConfigManager().mysqlDatabase();
            boolean useSsl = plugin.getConfigManager().mysqlUseSsl();

            String jdbcUrl = String.format(
                    "jdbc:mysql://%s:%d/%s?useSSL=%b&autoReconnect=true&characterEncoding=utf8&useUnicode=true",
                    host, port, database, useSsl);

            hikariConfig.setJdbcUrl(jdbcUrl);
            hikariConfig.setUsername(plugin.getConfigManager().mysqlUsername());
            hikariConfig.setPassword(plugin.getConfigManager().mysqlPassword());
            hikariConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
            hikariConfig.setMaximumPoolSize(plugin.getConfigManager().mysqlPoolSize());
            hikariConfig.addDataSourceProperty("cachePrepStmts", "true");
            hikariConfig.addDataSourceProperty("prepStmtCacheSize", "250");
            hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        } else {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) dataFolder.mkdirs();
            File dbFile = new File(dataFolder, plugin.getConfigManager().sqliteFile());
            hikariConfig.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
            hikariConfig.setDriverClassName("org.sqlite.JDBC");
            // SQLite only supports a single writer connection at a time.
            hikariConfig.setMaximumPoolSize(1);
        }

        hikariConfig.setPoolName("CaitAuth-Pool");
        hikariConfig.setConnectionTimeout(10_000);
        this.dataSource = new HikariDataSource(hikariConfig);

        createTables();
    }

    private void createTables() throws SQLException {
        String ddl = type == Type.MYSQL ? """
                CREATE TABLE IF NOT EXISTS caitauth_players (
                    uuid VARCHAR(36) PRIMARY KEY,
                    username VARCHAR(16) NOT NULL,
                    password_hash VARCHAR(255),
                    registration_date BIGINT NOT NULL,
                    last_login BIGINT,
                    last_ip VARCHAR(45),
                    premium BOOLEAN NOT NULL DEFAULT FALSE,
                    last_premium_verification BIGINT NOT NULL DEFAULT 0,
                    INDEX idx_username (username)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """ : """
                CREATE TABLE IF NOT EXISTS caitauth_players (
                    uuid TEXT PRIMARY KEY,
                    username TEXT NOT NULL,
                    password_hash TEXT,
                    registration_date INTEGER NOT NULL,
                    last_login INTEGER,
                    last_ip TEXT,
                    premium INTEGER NOT NULL DEFAULT 0,
                    last_premium_verification INTEGER NOT NULL DEFAULT 0
                )
                """;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(ddl)) {
            stmt.execute();
        }

        if (type == Type.SQLITE) {
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                         "CREATE INDEX IF NOT EXISTS idx_ca_username ON caitauth_players (username)")) {
                stmt.execute();
            }
        }
    }

    public void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    // ---------------------------------------------------------------------
    // Async API
    // ---------------------------------------------------------------------

    public CompletableFuture<Optional<PlayerData>> getPlayer(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = "SELECT * FROM caitauth_players WHERE uuid = ?";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, uuid.toString());
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return Optional.of(mapRow(rs));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to fetch player " + uuid + ": " + e.getMessage());
            }
            return Optional.empty();
        }, dbExecutor);
    }

    public CompletableFuture<Optional<PlayerData>> getPlayerByUsername(String username) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = "SELECT * FROM caitauth_players WHERE LOWER(username) = LOWER(?)";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return Optional.of(mapRow(rs));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to fetch player by username " + username + ": " + e.getMessage());
            }
            return Optional.empty();
        }, dbExecutor);
    }

    public CompletableFuture<Void> savePlayer(PlayerData data) {
        return CompletableFuture.runAsync(() -> {
            String sql = type == Type.MYSQL ? """
                    INSERT INTO caitauth_players
                        (uuid, username, password_hash, registration_date, last_login, last_ip, premium, last_premium_verification)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        username = VALUES(username),
                        password_hash = VALUES(password_hash),
                        last_login = VALUES(last_login),
                        last_ip = VALUES(last_ip),
                        premium = VALUES(premium),
                        last_premium_verification = VALUES(last_premium_verification)
                    """ : """
                    INSERT INTO caitauth_players
                        (uuid, username, password_hash, registration_date, last_login, last_ip, premium, last_premium_verification)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(uuid) DO UPDATE SET
                        username = excluded.username,
                        password_hash = excluded.password_hash,
                        last_login = excluded.last_login,
                        last_ip = excluded.last_ip,
                        premium = excluded.premium,
                        last_premium_verification = excluded.last_premium_verification
                    """;

            try (Connection conn = dataSource.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, data.getUuid().toString());
                stmt.setString(2, data.getUsername());
                stmt.setString(3, data.getPasswordHash());
                stmt.setLong(4, data.getRegistrationDate());
                stmt.setLong(5, data.getLastLogin());
                stmt.setString(6, data.getLastIp());
                stmt.setBoolean(7, data.isPremium());
                stmt.setLong(8, data.getLastPremiumVerification());
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to save player " + data.getUuid() + ": " + e.getMessage());
            }
        }, dbExecutor);
    }

    public CompletableFuture<Void> deletePlayer(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            String sql = "DELETE FROM caitauth_players WHERE uuid = ?";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, uuid.toString());
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to delete player " + uuid + ": " + e.getMessage());
            }
        }, dbExecutor);
    }

    public CompletableFuture<Void> updatePremiumFlag(UUID uuid, boolean premium, long verificationTime) {
        return CompletableFuture.runAsync(() -> {
            String sql = "UPDATE caitauth_players SET premium = ?, last_premium_verification = ? WHERE uuid = ?";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setBoolean(1, premium);
                stmt.setLong(2, verificationTime);
                stmt.setString(3, uuid.toString());
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to update premium flag for " + uuid + ": " + e.getMessage());
            }
        }, dbExecutor);
    }

    private PlayerData mapRow(ResultSet rs) throws SQLException {
        return new PlayerData(
                UUID.fromString(rs.getString("uuid")),
                rs.getString("username"),
                rs.getString("password_hash"),
                rs.getLong("registration_date"),
                rs.getLong("last_login"),
                rs.getString("last_ip"),
                rs.getBoolean("premium"),
                rs.getLong("last_premium_verification")
        );
    }

    public Type getType() { return type; }
}
