package com.caitauth.database;

import java.util.UUID;

/**
 * Immutable-ish snapshot of a player's stored authentication record.
 * Passed between the database layer and the auth layer.
 */
public final class PlayerData {

    private final UUID uuid;
    private final String username;
    private String passwordHash; // null for premium accounts
    private final long registrationDate;
    private long lastLogin;
    private String lastIp;
    private boolean premium;
    private long lastPremiumVerification;

    public PlayerData(UUID uuid, String username, String passwordHash, long registrationDate,
                       long lastLogin, String lastIp, boolean premium, long lastPremiumVerification) {
        this.uuid = uuid;
        this.username = username;
        this.passwordHash = passwordHash;
        this.registrationDate = registrationDate;
        this.lastLogin = lastLogin;
        this.lastIp = lastIp;
        this.premium = premium;
        this.lastPremiumVerification = lastPremiumVerification;
    }

    public UUID getUuid() { return uuid; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public long getRegistrationDate() { return registrationDate; }
    public long getLastLogin() { return lastLogin; }
    public void setLastLogin(long lastLogin) { this.lastLogin = lastLogin; }
    public String getLastIp() { return lastIp; }
    public void setLastIp(String lastIp) { this.lastIp = lastIp; }
    public boolean isPremium() { return premium; }
    public void setPremium(boolean premium) { this.premium = premium; }
    public long getLastPremiumVerification() { return lastPremiumVerification; }
    public void setLastPremiumVerification(long lastPremiumVerification) { this.lastPremiumVerification = lastPremiumVerification; }

    public boolean isRegistered() {
        return passwordHash != null && !passwordHash.isEmpty();
    }
}
