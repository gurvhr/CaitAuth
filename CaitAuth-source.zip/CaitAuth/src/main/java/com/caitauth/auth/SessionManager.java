package com.caitauth.auth;

import com.caitauth.CaitAuthPlugin;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks in-memory authentication state per online player, plus a lightweight
 * "remember me" session so a player who quits and reconnects within the
 * configured session window doesn't need to log in again.
 */
public final class SessionManager {

    private record Session(String ip, Instant expiresAt) {}

    private final CaitAuthPlugin plugin;

    // Players currently authenticated this connection (cleared on quit).
    private final Map<UUID, Boolean> authenticated = new ConcurrentHashMap<>();

    // Persistent-ish "remember me" sessions surviving a quit/rejoin within the window.
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();

    public SessionManager(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    public void markAuthenticated(UUID uuid, String ip) {
        authenticated.put(uuid, Boolean.TRUE);
        if (plugin.getConfigManager().sessionsEnabled()) {
            Instant expiry = Instant.now().plus(plugin.getConfigManager().sessionTime());
            sessions.put(uuid, new Session(ip, expiry));
        }
    }

    public boolean isAuthenticated(UUID uuid) {
        return authenticated.getOrDefault(uuid, Boolean.FALSE);
    }

    public void clearAuthenticated(UUID uuid) {
        authenticated.remove(uuid);
    }

    /** Called on quit — session record is kept (not authenticated map) so a fast rejoin can skip login. */
    public void onQuit(UUID uuid) {
        authenticated.remove(uuid);
    }

    /**
     * Checks whether a rejoining player has a still-valid remember-me session
     * for the given IP. Does not itself mark the player authenticated.
     */
    public boolean hasValidSession(UUID uuid, String ip) {
        if (!plugin.getConfigManager().sessionsEnabled()) return false;
        Session session = sessions.get(uuid);
        if (session == null) return false;
        if (Instant.now().isAfter(session.expiresAt())) {
            sessions.remove(uuid);
            return false;
        }
        if (plugin.getConfigManager().sessionBindIp() && !session.ip().equals(ip)) {
            return false;
        }
        return true;
    }

    public void invalidateSession(UUID uuid) {
        sessions.remove(uuid);
    }
}
