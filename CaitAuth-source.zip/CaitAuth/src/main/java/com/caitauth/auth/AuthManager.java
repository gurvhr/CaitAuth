package com.caitauth.auth;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.database.DatabaseManager;
import com.caitauth.database.PlayerData;
import com.caitauth.events.PlayerRegisterEvent;
import com.caitauth.events.PlayerLoginEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.mindrot.jbcrypt.BCrypt;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Core authentication service. All database-touching operations are async;
 * anything that must touch the Bukkit API (events, kicking, messaging) is
 * hopped back onto the main thread via the scheduler.
 */
public final class AuthManager {

    private final CaitAuthPlugin plugin;
    private final DatabaseManager db;
    private final SessionManager sessionManager;

    private final Map<UUID, AtomicInteger> loginAttempts = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> pendingLoginTasks = new ConcurrentHashMap<>();

    public AuthManager(CaitAuthPlugin plugin) {
        this.plugin = plugin;
        this.db = plugin.getDatabaseManager();
        this.sessionManager = plugin.getSessionManager();
    }

    public SessionManager getSessionManager() {
        return sessionManager;
    }

    public boolean isAuthenticated(Player player) {
        return sessionManager.isAuthenticated(player.getUniqueId());
    }

    // ---------------------------------------------------------------------
    // Registration
    // ---------------------------------------------------------------------

    public CompletableFuture<RegisterResult> register(Player player, String password, String confirmPassword) {
        UUID uuid = player.getUniqueId();

        if (!password.equals(confirmPassword)) {
            return CompletableFuture.completedFuture(RegisterResult.MISMATCH);
        }
        int min = plugin.getConfigManager().minPasswordLength();
        int max = plugin.getConfigManager().maxPasswordLength();
        if (password.length() < min) return CompletableFuture.completedFuture(RegisterResult.TOO_SHORT);
        if (password.length() > max) return CompletableFuture.completedFuture(RegisterResult.TOO_LONG);

        return db.getPlayer(uuid).thenCompose(existing -> {
            if (existing.isPresent() && existing.get().isPremium()) {
                return CompletableFuture.completedFuture(RegisterResult.PREMIUM_ACCOUNT);
            }
            if (existing.isPresent() && existing.get().isRegistered()) {
                return CompletableFuture.completedFuture(RegisterResult.ALREADY_REGISTERED);
            }

            String hash = BCrypt.hashpw(password, BCrypt.gensalt(12));
            long now = System.currentTimeMillis();
            String ip = ipOf(player);

            PlayerData data = new PlayerData(uuid, player.getName(), hash, now, now, ip, false, 0);

            return db.savePlayer(data).thenApply(v -> {
                sessionManager.markAuthenticated(uuid, ip);
                runOnMain(() -> {
                    resetAttempts(uuid);
                    Bukkit.getPluginManager().callEvent(new PlayerRegisterEvent(player));
                    Bukkit.getPluginManager().callEvent(new PlayerLoginEvent(player, PlayerLoginEvent.Cause.REGISTER));
                });
                return RegisterResult.SUCCESS;
            });
        }).exceptionally(ex -> {
            plugin.getLogger().severe("Registration error for " + player.getName() + ": " + ex.getMessage());
            return RegisterResult.FAILURE;
        });
    }

    public enum RegisterResult { SUCCESS, MISMATCH, TOO_SHORT, TOO_LONG, ALREADY_REGISTERED, PREMIUM_ACCOUNT, FAILURE }

    // ---------------------------------------------------------------------
    // Login
    // ---------------------------------------------------------------------

    public CompletableFuture<LoginResult> login(Player player, String password) {
        UUID uuid = player.getUniqueId();

        return db.getPlayer(uuid).thenCompose(opt -> {
            if (opt.isEmpty() || !opt.get().isRegistered()) {
                return CompletableFuture.completedFuture(LoginResult.NOT_REGISTERED);
            }
            PlayerData data = opt.get();
            if (data.isPremium()) {
                return CompletableFuture.completedFuture(LoginResult.PREMIUM_ACCOUNT);
            }

            boolean matches = BCrypt.checkpw(password, data.getPasswordHash());
            if (!matches) {
                int attempts = loginAttempts.computeIfAbsent(uuid, k -> new AtomicInteger()).incrementAndGet();
                int max = plugin.getConfigManager().maxLoginAttempts();
                if (attempts >= max) {
                    return CompletableFuture.completedFuture(LoginResult.MAX_ATTEMPTS);
                }
                return CompletableFuture.completedFuture(LoginResult.WRONG_PASSWORD);
            }

            String ip = ipOf(player);
            data.setLastLogin(System.currentTimeMillis());
            data.setLastIp(ip);

            return db.savePlayer(data).thenApply(v -> {
                sessionManager.markAuthenticated(uuid, ip);
                runOnMain(() -> {
                    resetAttempts(uuid);
                    cancelLoginTimeout(uuid);
                    Bukkit.getPluginManager().callEvent(new PlayerLoginEvent(player, PlayerLoginEvent.Cause.PASSWORD));
                });
                return LoginResult.SUCCESS;
            });
        }).exceptionally(ex -> {
            plugin.getLogger().severe("Login error for " + player.getName() + ": " + ex.getMessage());
            return LoginResult.FAILURE;
        });
    }

    public int getRemainingAttempts(UUID uuid) {
        int used = loginAttempts.getOrDefault(uuid, new AtomicInteger()).get();
        return Math.max(0, plugin.getConfigManager().maxLoginAttempts() - used);
    }

    public void resetAttempts(UUID uuid) {
        loginAttempts.remove(uuid);
    }

    public enum LoginResult { SUCCESS, NOT_REGISTERED, WRONG_PASSWORD, MAX_ATTEMPTS, PREMIUM_ACCOUNT, FAILURE }

    // ---------------------------------------------------------------------
    // Auto-login (premium / session restore)
    // ---------------------------------------------------------------------

    public void autoAuthenticate(Player player) {
        sessionManager.markAuthenticated(player.getUniqueId(), ipOf(player));
        cancelLoginTimeout(player.getUniqueId());
    }

    // ---------------------------------------------------------------------
    // Change password
    // ---------------------------------------------------------------------

    public CompletableFuture<ChangePasswordResult> changePassword(Player player, String oldPassword, String newPassword) {
        UUID uuid = player.getUniqueId();
        return db.getPlayer(uuid).thenCompose(opt -> {
            if (opt.isEmpty() || !opt.get().isRegistered()) {
                return CompletableFuture.completedFuture(ChangePasswordResult.NOT_REGISTERED);
            }
            PlayerData data = opt.get();
            if (data.isPremium()) {
                return CompletableFuture.completedFuture(ChangePasswordResult.PREMIUM_ACCOUNT);
            }
            if (!BCrypt.checkpw(oldPassword, data.getPasswordHash())) {
                return CompletableFuture.completedFuture(ChangePasswordResult.WRONG_PASSWORD);
            }
            int min = plugin.getConfigManager().minPasswordLength();
            int max = plugin.getConfigManager().maxPasswordLength();
            if (newPassword.length() < min) return CompletableFuture.completedFuture(ChangePasswordResult.TOO_SHORT);
            if (newPassword.length() > max) return CompletableFuture.completedFuture(ChangePasswordResult.TOO_LONG);

            data.setPasswordHash(BCrypt.hashpw(newPassword, BCrypt.gensalt(12)));
            return db.savePlayer(data).thenApply(v -> ChangePasswordResult.SUCCESS);
        }).exceptionally(ex -> {
            plugin.getLogger().severe("Change password error for " + player.getName() + ": " + ex.getMessage());
            return ChangePasswordResult.FAILURE;
        });
    }

    public enum ChangePasswordResult { SUCCESS, NOT_REGISTERED, WRONG_PASSWORD, TOO_SHORT, TOO_LONG, PREMIUM_ACCOUNT, FAILURE }

    // ---------------------------------------------------------------------
    // Unregister
    // ---------------------------------------------------------------------

    public CompletableFuture<Boolean> unregisterSelf(Player player, String password) {
        UUID uuid = player.getUniqueId();
        return db.getPlayer(uuid).thenCompose(opt -> {
            if (opt.isEmpty() || !opt.get().isRegistered()) {
                return CompletableFuture.completedFuture(false);
            }
            if (!BCrypt.checkpw(password, opt.get().getPasswordHash())) {
                return CompletableFuture.completedFuture(false);
            }
            return db.deletePlayer(uuid).thenApply(v -> {
                sessionManager.clearAuthenticated(uuid);
                sessionManager.invalidateSession(uuid);
                return true;
            });
        });
    }

    public CompletableFuture<Boolean> unregisterOther(UUID target) {
        return db.getPlayer(target).thenCompose(opt -> {
            if (opt.isEmpty()) return CompletableFuture.completedFuture(false);
            return db.deletePlayer(target).thenApply(v -> {
                sessionManager.clearAuthenticated(target);
                sessionManager.invalidateSession(target);
                return true;
            });
        });
    }

    // ---------------------------------------------------------------------
    // Login timeout enforcement
    // ---------------------------------------------------------------------

    public void scheduleLoginTimeout(Player player) {
        int seconds = plugin.getConfigManager().loginTimeoutSeconds();
        if (seconds <= 0) return;
        UUID uuid = player.getUniqueId();
        int taskId = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!sessionManager.isAuthenticated(uuid)) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    p.kick(net.kyori.adventure.text.Component.text(
                            plugin.getMessagesManager().getRaw("login.timeout")));
                }
            }
            pendingLoginTasks.remove(uuid);
        }, seconds * 20L).getTaskId();
        pendingLoginTasks.put(uuid, taskId);
    }

    public void cancelLoginTimeout(UUID uuid) {
        Integer taskId = pendingLoginTasks.remove(uuid);
        if (taskId != null) {
            Bukkit.getScheduler().cancelTask(taskId);
        }
    }

    public void cleanup(UUID uuid) {
        loginAttempts.remove(uuid);
        cancelLoginTimeout(uuid);
        sessionManager.onQuit(uuid);
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private String ipOf(Player player) {
        return player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "unknown";
    }

    private void runOnMain(Runnable runnable) {
        if (Bukkit.isPrimaryThread()) {
            runnable.run();
        } else {
            Bukkit.getScheduler().runTask(plugin, runnable);
        }
    }
}
