package com.caitauth.auth;

import com.caitauth.CaitAuthPlugin;
import org.bukkit.Bukkit;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.util.UUID;

/**
 * Determines whether an incoming connection is a genuine Mojang/Microsoft
 * authenticated ("premium") account.
 *
 * Detection strategy, in order:
 *  1. Floodgate/Bedrock players are treated as their own category (never
 *     required to register/login through CaitAuth — Floodgate already
 *     handles Bedrock identity linking).
 *  2. If the server itself runs in online-mode, Paper has already performed
 *     Mojang authentication before AsyncPlayerPreLoginEvent fires with
 *     LoginResult.ALLOWED — so any successful pre-login here is premium.
 *  3. If the server runs in offline-mode behind a proxy with forwarding
 *     enabled (Velocity modern or BungeeCord legacy/IP forwarding), the
 *     proxy has already authenticated the player with Mojang and forwarded
 *     a verified UUID. Paper (with `velocity-support` or
 *     `bungeecord: true` in its own config) exposes this as a proper
 *     online UUID at pre-login time as well, so the same check applies.
 *  4. Otherwise (offline-mode, no proxy forwarding) — the player is treated
 *     as cracked, regardless of what username they claim.
 */
public final class PremiumVerifier {

    private final CaitAuthPlugin plugin;

    public PremiumVerifier(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Must be called from {@code AsyncPlayerPreLoginEvent} (async pre-login),
     * which is the only point where Paper has already completed Mojang
     * authentication (directly, or via trusted proxy forwarding) before the
     * player object even exists.
     */
    public boolean isPremiumPreLogin(AsyncPlayerPreLoginEvent event) {
        if (isFloodgatePlayer(event.getUniqueId())) {
            // Bedrock players are handled by Floodgate's own auth; never gate them here.
            return true;
        }

        // Server is genuinely online-mode (standalone, or Paper configured with
        // velocity-support/bungeecord forwarding which internally still performs
        // Mojang auth and only then fires this event as ALLOWED).
        if (Bukkit.getOnlineMode()) {
            return event.getLoginResult() == AsyncPlayerPreLoginEvent.Result.ALLOWED;
        }

        // Offline-mode: only trust proxy forwarding if explicitly configured and
        // paper.yml / spigot.yml is set up correctly for it. We cannot re-verify
        // the proxy's Mojang handshake ourselves, so we rely on server operator
        // configuration (proxy.enabled + proxy.forwarding-mode) as an explicit
        // opt-in. Paper's own forwarding config already rejects unsigned/forged
        // packets before this event ever fires.
        if (plugin.getConfigManager().proxyEnabled()) {
            String mode = plugin.getConfigManager().forwardingMode();
            if (mode.equalsIgnoreCase("VELOCITY_MODERN") || mode.equalsIgnoreCase("BUNGEE_LEGACY")) {
                // At this point Paper's networking layer has already validated the
                // forwarded handshake (velocity secret / bungee IP forwarding) —
                // if it hadn't, the connection would have been rejected earlier
                // and this event would never fire. A UUID version of 4 with
                // variant bits set the way Mojang generates them is the strongest
                // signal available to us at this layer.
                return looksLikeMojangUuid(event.getUniqueId());
            }
        }

        return false;
    }

    /** Re-verification for cached premium flags — lightweight heuristic re-check. */
    public boolean isPremiumUuid(UUID uuid) {
        return looksLikeMojangUuid(uuid);
    }

    private boolean looksLikeMojangUuid(UUID uuid) {
        // Mojang-issued UUIDs are version 4 (random) or version 3 depending on
        // generation era, but critically are NOT the offline-mode UUIDs Bukkit
        // generates deterministically via UUID.nameUUIDFromBytes("OfflinePlayer:" + name).
        // We cross-check against what an offline UUID for this connection *would*
        // look like where possible; here we simply validate version bits as a
        // final sanity check since true verification already happened upstream.
        return uuid.version() == 4;
    }

    private boolean isFloodgatePlayer(UUID uuid) {
        if (!Bukkit.getPluginManager().isPluginEnabled("floodgate")) {
            return false;
        }
        try {
            Class<?> apiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Object instance = apiClass.getMethod("getInstance").invoke(null);
            Object result = apiClass.getMethod("isFloodgatePlayer", UUID.class).invoke(instance, uuid);
            return result instanceof Boolean b && b;
        } catch (Throwable t) {
            // Floodgate not present or API mismatch — fail safe to "not a bedrock player".
            return false;
        }
    }
}
