package com.caitauth.config;

import com.caitauth.CaitAuthPlugin;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Loads a language file (messages_<lang>.yml) from the plugin's data folder,
 * falling back to the bundled resource, and renders messages with
 * '&' color codes and %placeholder% substitution.
 */
public final class MessagesManager {

    private final CaitAuthPlugin plugin;
    private FileConfiguration messages;

    public MessagesManager(CaitAuthPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        String lang = plugin.getConfigManager().language();
        String fileName = "messages_" + lang + ".yml";
        File file = new File(plugin.getDataFolder(), fileName);

        if (!file.exists()) {
            // Try to copy the bundled resource, falling back to English.
            if (plugin.getResource(fileName) != null) {
                plugin.saveResource(fileName, false);
            } else {
                fileName = "messages_en.yml";
                file = new File(plugin.getDataFolder(), fileName);
                if (!file.exists()) {
                    plugin.saveResource(fileName, false);
                }
            }
        }

        messages = YamlConfiguration.loadConfiguration(file);

        // Fill in any missing keys from the bundled default so upgrades don't break.
        try (InputStream defStream = plugin.getResource("messages_en.yml")) {
            if (defStream != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defStream, StandardCharsets.UTF_8));
                messages.setDefaults(defaults);
            }
        } catch (Exception ignored) {
            // Non-fatal: worst case, missing keys render as their raw path.
        }
    }

    public void reload() {
        load();
    }

    private String raw(String path) {
        String value = messages.getString(path);
        return value != null ? value : messages.getDefaults() != null
                ? messages.getDefaults().getString(path, path)
                : path;
    }

    public String get(String path) {
        return colorize(withPrefix(path, raw(path)));
    }

    public String get(String path, Map<String, String> placeholders) {
        String value = withPrefix(path, raw(path));
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            value = value.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        return colorize(value);
    }

    public String getRaw(String path) {
        return colorize(raw(path));
    }

    /** Prefixes standalone status/info lines but not the prefix key itself. */
    private String withPrefix(String path, String value) {
        if (path.equals("prefix")) return value;
        boolean noPrefixSections = path.startsWith("admin.info");
        if (noPrefixSections) return value;
        return raw("prefix") + value;
    }

    private String colorize(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    public void send(CommandSender sender, String path) {
        sender.sendMessage(get(path));
    }

    public void send(CommandSender sender, String path, Map<String, String> placeholders) {
        sender.sendMessage(get(path, placeholders));
    }
}
