package com.caitauth.config;

import com.caitauth.CaitAuthPlugin;
import org.bukkit.configuration.file.FileConfiguration;

import java.time.Duration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Central, typed accessor for config.yml. Reload-safe: call {@link #reload()}
 * whenever the plugin config is reloaded and every getter will reflect fresh values.
 */
public final class ConfigManager {

    private static final Pattern DURATION_PATTERN = Pattern.compile("(\\d+)([smhd])");

    private final CaitAuthPlugin plugin;
    private FileConfiguration cfg;

    public ConfigManager(CaitAuthPlugin plugin) {
        this.plugin = plugin;
        this.plugin.saveDefaultConfig();
        this.cfg = plugin.getConfig();
    }

    public void reload() {
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
    }

    // ----- premium -----
    public boolean premiumAutoDetect() { return cfg.getBoolean("premium.auto-detect", true); }
    public int premiumCacheDays() { return cfg.getInt("premium.cache-days", 30); }
    public boolean protectPremiumNames() { return cfg.getBoolean("premium.protect-premium-names", true); }

    // ----- proxy -----
    public boolean proxyEnabled() { return cfg.getBoolean("proxy.enabled", false); }
    public String forwardingMode() { return cfg.getString("proxy.forwarding-mode", "NONE"); }
    public String velocitySecret() { return cfg.getString("proxy.velocity-secret", ""); }

    // ----- login -----
    public int loginTimeoutSeconds() { return cfg.getInt("login.timeout", 60); }
    public int maxLoginAttempts() { return cfg.getInt("login.max-attempts", 5); }

    // ----- registration -----
    public int minPasswordLength() { return cfg.getInt("registration.min-password-length", 6); }
    public int maxPasswordLength() { return cfg.getInt("registration.max-password-length", 64); }

    // ----- sessions -----
    public boolean sessionsEnabled() { return cfg.getBoolean("sessions.enabled", true); }
    public boolean sessionBindIp() { return cfg.getBoolean("sessions.bind-ip", true); }
    public Duration sessionTime() { return parseDuration(cfg.getString("sessions.session-time", "15m")); }

    // ----- database -----
    public String databaseType() { return cfg.getString("database.type", "sqlite").toLowerCase(); }
    public String sqliteFile() { return cfg.getString("database.sqlite.file", "database.db"); }
    public String mysqlHost() { return cfg.getString("database.mysql.host", "localhost"); }
    public int mysqlPort() { return cfg.getInt("database.mysql.port", 3306); }
    public String mysqlDatabase() { return cfg.getString("database.mysql.database", "caitauth"); }
    public String mysqlUsername() { return cfg.getString("database.mysql.username", "root"); }
    public String mysqlPassword() { return cfg.getString("database.mysql.password", ""); }
    public boolean mysqlUseSsl() { return cfg.getBoolean("database.mysql.use-ssl", false); }
    public int mysqlPoolSize() { return cfg.getInt("database.mysql.pool-size", 10); }

    // ----- protection -----
    public boolean blockMovement() { return cfg.getBoolean("protection.block-movement", true); }
    public boolean blockCommands() { return cfg.getBoolean("protection.block-commands", true); }
    public boolean blockItemPickup() { return cfg.getBoolean("protection.block-item-pickup", true); }
    public boolean blockItemDrop() { return cfg.getBoolean("protection.block-item-drop", true); }
    public boolean blockInventory() { return cfg.getBoolean("protection.block-inventory", true); }
    public boolean blockBlockBreak() { return cfg.getBoolean("protection.block-block-break", true); }
    public boolean blockBlockPlace() { return cfg.getBoolean("protection.block-block-place", true); }
    public boolean blockEntityDamage() { return cfg.getBoolean("protection.block-entity-damage", true); }
    public boolean blockChat() { return cfg.getBoolean("protection.block-chat", true); }
    public boolean blockTeleport() { return cfg.getBoolean("protection.block-teleport", true); }
    public List<String> allowedCommands() { return cfg.getStringList("protection.allowed-commands"); }

    // ----- messages -----
    public String language() { return cfg.getString("messages.language", "en"); }

    public boolean metricsEnabled() { return cfg.getBoolean("metrics.enabled", true); }

    private Duration parseDuration(String input) {
        if (input == null || input.isBlank()) return Duration.ofMinutes(15);
        Matcher m = DURATION_PATTERN.matcher(input.trim());
        if (!m.matches()) return Duration.ofMinutes(15);
        long value = Long.parseLong(m.group(1));
        return switch (m.group(2)) {
            case "s" -> Duration.ofSeconds(value);
            case "m" -> Duration.ofMinutes(value);
            case "h" -> Duration.ofHours(value);
            case "d" -> Duration.ofDays(value);
            default -> Duration.ofMinutes(15);
        };
    }
}
