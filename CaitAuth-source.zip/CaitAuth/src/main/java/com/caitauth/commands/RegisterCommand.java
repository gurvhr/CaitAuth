package com.caitauth.commands;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.auth.AuthManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class RegisterCommand implements CommandExecutor {

    private final CaitAuthPlugin plugin;

    public RegisterCommand(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.player-only"));
            return true;
        }

        if (plugin.getAuthManager().isAuthenticated(player)) {
            plugin.getMessagesManager().send(player, "login.already-logged-in");
            return true;
        }

        if (args.length != 2) {
            plugin.getMessagesManager().send(player, "register.usage");
            return true;
        }

        String password = args[0];
        String confirm = args[1];

        plugin.getAuthManager().register(player, password, confirm).thenAccept(result -> {
            plugin.getServer().getScheduler().runTask(plugin, () -> handleResult(player, result));
        });

        return true;
    }

    private void handleResult(Player player, AuthManager.RegisterResult result) {
        if (!player.isOnline()) return;
        switch (result) {
            case SUCCESS -> plugin.getMessagesManager().send(player, "register.success");
            case MISMATCH -> plugin.getMessagesManager().send(player, "register.mismatch");
            case TOO_SHORT -> plugin.getMessagesManager().send(player, "register.too-short",
                    Map.of("min", String.valueOf(plugin.getConfigManager().minPasswordLength())));
            case TOO_LONG -> plugin.getMessagesManager().send(player, "register.too-long",
                    Map.of("max", String.valueOf(plugin.getConfigManager().maxPasswordLength())));
            case ALREADY_REGISTERED -> plugin.getMessagesManager().send(player, "register.already-registered");
            case PREMIUM_ACCOUNT -> plugin.getMessagesManager().send(player, "register.premium-cannot-register");
            case FAILURE -> plugin.getMessagesManager().send(player, "register.failure");
        }
    }
}
