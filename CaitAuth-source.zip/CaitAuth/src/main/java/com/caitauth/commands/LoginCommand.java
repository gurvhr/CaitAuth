package com.caitauth.commands;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.auth.AuthManager;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class LoginCommand implements CommandExecutor {

    private final CaitAuthPlugin plugin;

    public LoginCommand(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.player-only"));
            return true;
        }

        if (plugin.getAuthManager().isAuthenticated(player)) {
            plugin.getMessagesManager().send(player, "login.already-logged-in");
            return true;
        }

        if (args.length != 1) {
            plugin.getMessagesManager().send(player, "login.usage");
            return true;
        }

        plugin.getAuthManager().login(player, args[0]).thenAccept(result ->
                plugin.getServer().getScheduler().runTask(plugin, () -> handleResult(player, result)));

        return true;
    }

    private void handleResult(Player player, AuthManager.LoginResult result) {
        if (!player.isOnline()) return;
        switch (result) {
            case SUCCESS -> plugin.getMessagesManager().send(player, "login.success");
            case NOT_REGISTERED -> plugin.getMessagesManager().send(player, "login.not-registered");
            case WRONG_PASSWORD -> plugin.getMessagesManager().send(player, "login.wrong-password",
                    Map.of("attempts", String.valueOf(plugin.getAuthManager().getRemainingAttempts(player.getUniqueId()))));
            case MAX_ATTEMPTS -> player.kick(Component.text(
                    net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&',
                            plugin.getMessagesManager().getRaw("login.max-attempts"))));
            case PREMIUM_ACCOUNT -> plugin.getMessagesManager().send(player, "register.premium-cannot-register");
            case FAILURE -> plugin.getMessagesManager().send(player, "general.unknown-error");
        }
    }
}
