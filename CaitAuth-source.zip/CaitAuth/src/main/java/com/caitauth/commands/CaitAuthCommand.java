package com.caitauth.commands;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.database.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CaitAuthCommand implements CommandExecutor, TabCompleter {

    private final CaitAuthPlugin plugin;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public CaitAuthCommand(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("caitauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.no-permission"));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("§bCaitAuth §7— /caitauth <reload|premium|cracked|info> [player]");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "premium" -> handleSetPremium(sender, args, true);
            case "cracked" -> handleSetPremium(sender, args, false);
            case "info" -> handleInfo(sender, args);
            default -> sender.sendMessage("§bCaitAuth §7— /caitauth <reload|premium|cracked|info> [player]");
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("caitauth.reload")) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.no-permission"));
            return;
        }
        plugin.reload();
        sender.sendMessage(plugin.getMessagesManager().get("admin.reload-success"));
    }

    private void handleSetPremium(CommandSender sender, String[] args, boolean premium) {
        if (args.length != 2) {
            sender.sendMessage("§cUsage: /caitauth " + (premium ? "premium" : "cracked") + " <player>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.player-not-found"));
            return;
        }

        plugin.getDatabaseManager().updatePremiumFlag(target.getUniqueId(), premium, System.currentTimeMillis())
                .thenRun(() -> Bukkit.getScheduler().runTask(plugin, () -> {
                    String key = premium ? "admin.set-premium" : "admin.set-cracked";
                    sender.sendMessage(plugin.getMessagesManager().get(key, Map.of("player", args[1])));
                    if (target.isOnline() && premium) {
                        plugin.getAuthManager().autoAuthenticate((org.bukkit.entity.Player) target);
                    }
                }));
    }

    private void handleInfo(CommandSender sender, String[] args) {
        if (args.length != 2) {
            sender.sendMessage("§cUsage: /caitauth info <player>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        plugin.getDatabaseManager().getPlayer(target.getUniqueId()).thenAccept(opt ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (opt.isEmpty()) {
                        sender.sendMessage(plugin.getMessagesManager().get("admin.player-not-found"));
                        return;
                    }
                    PlayerData data = opt.get();
                    sender.sendMessage(plugin.getMessagesManager().get("admin.info-header", Map.of("player", args[1])));
                    sender.sendMessage(plugin.getMessagesManager().get("admin.info-uuid", Map.of("uuid", data.getUuid().toString())));
                    sender.sendMessage(plugin.getMessagesManager().get("admin.info-premium", Map.of("premium", String.valueOf(data.isPremium()))));
                    sender.sendMessage(plugin.getMessagesManager().get("admin.info-registered",
                            Map.of("registered", data.getRegistrationDate() > 0 ? DATE_FORMAT.format(new Date(data.getRegistrationDate())) : "N/A")));
                    sender.sendMessage(plugin.getMessagesManager().get("admin.info-last-login",
                            Map.of("lastlogin", data.getLastLogin() > 0 ? DATE_FORMAT.format(new Date(data.getLastLogin())) : "N/A")));
                    sender.sendMessage(plugin.getMessagesManager().get("admin.info-last-ip",
                            Map.of("lastip", data.getLastIp() != null ? data.getLastIp() : "N/A")));
                }));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("caitauth.admin")) return List.of();

        if (args.length == 1) {
            return filter(List.of("reload", "premium", "cracked", "info"), args[0]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("premium")
                || args[0].equalsIgnoreCase("cracked") || args[0].equalsIgnoreCase("info"))) {
            return filter(Bukkit.getOnlinePlayers().stream().map(p -> p.getName()).collect(Collectors.toList()), args[1]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        List<String> result = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase().startsWith(prefix.toLowerCase())) {
                result.add(option);
            }
        }
        return result;
    }
}
