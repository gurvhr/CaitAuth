package com.caitauth.commands;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.auth.AuthManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class ChangePasswordCommand implements CommandExecutor {

    private final CaitAuthPlugin plugin;

    public ChangePasswordCommand(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.player-only"));
            return true;
        }

        if (!plugin.getAuthManager().isAuthenticated(player)) {
            plugin.getMessagesManager().send(player, "protection.must-login");
            return true;
        }

        if (args.length != 2) {
            plugin.getMessagesManager().send(player, "changepassword.usage");
            return true;
        }

        plugin.getAuthManager().changePassword(player, args[0], args[1]).thenAccept(result ->
                plugin.getServer().getScheduler().runTask(plugin, () -> handleResult(player, result)));

        return true;
    }

    private void handleResult(Player player, AuthManager.ChangePasswordResult result) {
        if (!player.isOnline()) return;
        switch (result) {
            case SUCCESS -> plugin.getMessagesManager().send(player, "changepassword.success");
            case WRONG_PASSWORD -> plugin.getMessagesManager().send(player, "changepassword.wrong-old-password");
            case NOT_REGISTERED -> plugin.getMessagesManager().send(player, "login.not-registered");
            case PREMIUM_ACCOUNT -> plugin.getMessagesManager().send(player, "changepassword.premium-cannot-change");
            case TOO_SHORT -> plugin.getMessagesManager().send(player, "register.too-short",
                    Map.of("min", String.valueOf(plugin.getConfigManager().minPasswordLength())));
            case TOO_LONG -> plugin.getMessagesManager().send(player, "register.too-long",
                    Map.of("max", String.valueOf(plugin.getConfigManager().maxPasswordLength())));
            case FAILURE -> plugin.getMessagesManager().send(player, "general.unknown-error");
        }
    }
}
