package com.caitauth.commands;

import com.caitauth.CaitAuthPlugin;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

/**
 * Two modes:
 *  - Self-service: /unregister <yourPassword>  (any authenticated cracked player)
 *  - Admin: /unregister <playerName>            (requires caitauth.unregister, no password needed)
 */
public class UnregisterCommand implements CommandExecutor {

    private final CaitAuthPlugin plugin;

    public UnregisterCommand(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 1) {
            sender.sendMessage(plugin.getMessagesManager().get("unregister.usage"));
            return true;
        }

        // Admin path: target is a known player name and sender has permission.
        if (sender.hasPermission("caitauth.unregister")) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
            if (target.hasPlayedBefore() || target.isOnline()) {
                plugin.getAuthManager().unregisterOther(target.getUniqueId()).thenAccept(success ->
                        Bukkit.getScheduler().runTask(plugin, () -> {
                            if (success) {
                                sender.sendMessage(plugin.getMessagesManager().get("unregister.admin-success",
                                        Map.of("player", args[0])));
                            } else {
                                sender.sendMessage(plugin.getMessagesManager().get("unregister.not-found"));
                            }
                        }));
                return true;
            }
        }

        // Self-service path requires a player invoking with their own password.
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.player-only"));
            return true;
        }

        if (!plugin.getAuthManager().isAuthenticated(player)) {
            plugin.getMessagesManager().send(player, "protection.must-login");
            return true;
        }

        plugin.getAuthManager().unregisterSelf(player, args[0]).thenAccept(success ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (success) {
                        plugin.getMessagesManager().send(player, "unregister.success");
                    } else {
                        plugin.getMessagesManager().send(player, "unregister.wrong-password");
                    }
                }));

        return true;
    }
}
