package com.caitauth.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired whenever a player becomes authenticated with CaitAuth, regardless of
 * whether that happened via password login, registration, premium
 * auto-auth, or restored session. This class lives at
 * "com.caitauth.events.PlayerLoginEvent" — fully qualify or import carefully
 * to avoid confusion with Bukkit's own org.bukkit.event.player.PlayerLoginEvent.
 */
public class PlayerLoginEvent extends Event {

    public enum Cause { PASSWORD, REGISTER, PREMIUM, SESSION_RESTORE }

    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final Cause cause;

    public PlayerLoginEvent(Player player, Cause cause) {
        this.player = player;
        this.cause = cause;
    }

    public Player getPlayer() { return player; }
    public Cause getCause() { return cause; }

    @Override
    public HandlerList getHandlers() { return HANDLERS; }

    public static HandlerList getHandlerList() { return HANDLERS; }
}
