package com.caitauth.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired when a premium (Mojang/Microsoft authenticated) player joins and is
 * auto-authenticated without needing /register or /login.
 */
public class PremiumPlayerJoinEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;

    public PremiumPlayerJoinEvent(Player player) {
        this.player = player;
    }

    public Player getPlayer() { return player; }

    @Override
    public HandlerList getHandlers() { return HANDLERS; }

    public static HandlerList getHandlerList() { return HANDLERS; }
}
