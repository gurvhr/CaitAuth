package com.caitauth.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired when a cracked (non-premium) player joins and must go through
 * /register or /login before being granted full access.
 */
public class CrackedPlayerJoinEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final boolean needsRegistration;

    public CrackedPlayerJoinEvent(Player player, boolean needsRegistration) {
        this.player = player;
        this.needsRegistration = needsRegistration;
    }

    public Player getPlayer() { return player; }

    /** True if this player has never registered before and must use /register. */
    public boolean needsRegistration() { return needsRegistration; }

    @Override
    public HandlerList getHandlers() { return HANDLERS; }

    public static HandlerList getHandlerList() { return HANDLERS; }
}
