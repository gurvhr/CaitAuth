package com.caitauth.listeners;

import com.caitauth.CaitAuthPlugin;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Map;

/**
 * Restricts unauthenticated players to essentially a frozen, harmless state:
 * they cannot move (beyond looking around), interact with the world, take or
 * deal damage, pick up/drop items, or be teleported by exploit vectors.
 */
public class ProtectionListener implements Listener {

    private final CaitAuthPlugin plugin;

    public ProtectionListener(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean requiresAuth(Player player) {
        if (player.hasPermission("caitauth.bypass")) return false;
        return !plugin.getAuthManager().isAuthenticated(player);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.getConfigManager().blockMovement()) return;
        if (!requiresAuth(event.getPlayer())) return;

        // Allow head rotation (looking around) but cancel any actual positional change.
        if (event.getFrom().getX() != event.getTo().getX()
                || event.getFrom().getY() != event.getTo().getY()
                || event.getFrom().getZ() != event.getTo().getZ()) {
            event.setTo(event.getFrom());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (!plugin.getConfigManager().blockTeleport()) return;
        if (!requiresAuth(event.getPlayer())) return;

        // Allow only teleports our own plugin issues (e.g. none currently) — block everything else,
        // which covers ender pearls, chorus fruit, and third-party teleport exploits pre-auth.
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.ENDER_PEARL
                || cause == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT
                || cause == PlayerTeleportEvent.TeleportCause.PLUGIN
                || cause == PlayerTeleportEvent.TeleportCause.COMMAND) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!plugin.getConfigManager().blockItemPickup()) return;
        if (!(event.getEntity() instanceof Player player)) return;
        if (requiresAuth(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (!plugin.getConfigManager().blockItemDrop()) return;
        if (requiresAuth(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!plugin.getConfigManager().blockInventory()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (requiresAuth(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!plugin.getConfigManager().blockInventory()) return;
        if (!(event.getPlayer() instanceof Player player)) return;
        if (requiresAuth(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (!plugin.getConfigManager().blockBlockBreak()) return;
        if (requiresAuth(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!plugin.getConfigManager().blockBlockPlace()) return;
        if (requiresAuth(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!plugin.getConfigManager().blockEntityDamage()) return;
        if (!(event.getEntity() instanceof Player player)) return;
        // Unauthenticated players are invulnerable to prevent death/kill exploits pre-auth.
        if (requiresAuth(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        if (!plugin.getConfigManager().blockEntityDamage()) return;
        Entity damager = event.getDamager();
        // Unauthenticated players may not damage anything else either.
        if (damager instanceof Player attacker && requiresAuth(attacker)) {
            event.setCancelled(true);
        }
    }
}
