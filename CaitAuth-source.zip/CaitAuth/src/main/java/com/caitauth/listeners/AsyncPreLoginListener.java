package com.caitauth.listeners;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.database.PlayerData;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

/**
 * Runs during the async pre-login phase — before a Player object exists —
 * to classify the connecting account as premium or cracked and persist that
 * classification. This is the only reliable point at which Paper has
 * already completed (or forwarded) Mojang authentication.
 */
public class AsyncPreLoginListener implements Listener {

    private final CaitAuthPlugin plugin;

    public AsyncPreLoginListener(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        if (event.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) {
            return; // Already denied upstream (banned, server full pre-checks, etc.)
        }

        UUID uuid = event.getUniqueId();
        String username = event.getName();

        boolean detectedPremium = plugin.getConfigManager().premiumAutoDetect()
                && plugin.getPremiumVerifier().isPremiumPreLogin(event);

        try {
            Optional<PlayerData> existing = plugin.getDatabaseManager().getPlayer(uuid).get();

            if (plugin.getConfigManager().protectPremiumNames() && !detectedPremium) {
                // Name-squatting protection: if a *different* UUID is on record as the
                // verified premium owner of this username, refuse the cracked connection.
                Optional<PlayerData> byName = plugin.getDatabaseManager().getPlayerByUsername(username).get();
                if (byName.isPresent() && byName.get().isPremium() && !byName.get().getUuid().equals(uuid)) {
                    event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                            net.kyori.adventure.text.Component.text(
                                    net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&',
                                            "&cThis username belongs to a premium account. If it's yours, log in with the official Minecraft launcher.")));
                    return;
                }
            }

            long now = System.currentTimeMillis();

            if (existing.isEmpty()) {
                // Brand new account — persist its classification immediately.
                PlayerData fresh = new PlayerData(uuid, username, null, now, 0, null, detectedPremium, now);
                plugin.getDatabaseManager().savePlayer(fresh).get();
            } else {
                PlayerData data = existing.get();
                boolean shouldRefresh = isCacheStale(data.getLastPremiumVerification());
                if (detectedPremium != data.isPremium() || shouldRefresh) {
                    data.setPremium(detectedPremium);
                    data.setLastPremiumVerification(now);
                    plugin.getDatabaseManager().savePlayer(data).get();
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            plugin.getLogger().severe("Pre-login classification failed for " + username + ": " + e.getMessage());
        }
    }

    private boolean isCacheStale(long lastVerification) {
        long cacheMillis = plugin.getConfigManager().premiumCacheDays() * 24L * 60L * 60L * 1000L;
        return (System.currentTimeMillis() - lastVerification) > cacheMillis;
    }
}
