package com.caitauth.listeners;

import com.caitauth.CaitAuthPlugin;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.List;
import java.util.Locale;

public class ChatCommandGuardListener implements Listener {

    private final CaitAuthPlugin plugin;

    public ChatCommandGuardListener(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean requiresAuth(Player player) {
        if (player.hasPermission("caitauth.bypass")) return false;
        return !plugin.getAuthManager().isAuthenticated(player);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!plugin.getConfigManager().blockChat()) return;
        Player player = event.getPlayer();
        if (requiresAuth(player)) {
            event.setCancelled(true);
            plugin.getMessagesManager().send(player, "protection.chat-blocked");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getConfigManager().blockCommands()) return;
        Player player = event.getPlayer();
        if (!requiresAuth(player)) return;

        String message = event.getMessage().toLowerCase(Locale.ROOT);
        List<String> allowed = plugin.getConfigManager().allowedCommands();
        boolean isAllowed = allowed.stream().anyMatch(cmd -> message.startsWith(cmd.toLowerCase(Locale.ROOT)));

        if (!isAllowed) {
            event.setCancelled(true);
            plugin.getMessagesManager().send(player, "protection.command-blocked");
        }
    }
}
