package com.caitauth.listeners;

import com.caitauth.CaitAuthPlugin;
import com.caitauth.database.PlayerData;
import com.caitauth.events.CrackedPlayerJoinEvent;
import com.caitauth.events.PlayerLoginEvent;
import com.caitauth.events.PremiumPlayerJoinEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.Optional;

public class PlayerJoinQuitListener implements Listener {

    private final CaitAuthPlugin plugin;

    public PlayerJoinQuitListener(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Freeze the player in an unauthenticated state until we resolve their record.
        plugin.getSessionManager().clearAuthenticated(player.getUniqueId());

        plugin.getDatabaseManager().getPlayer(player.getUniqueId()).thenAccept(opt ->
                Bukkit.getScheduler().runTask(plugin, () -> handleResolvedPlayer(player, opt))
        );
    }

    private void handleResolvedPlayer(Player player, Optional<PlayerData> opt) {
        if (!player.isOnline()) return;

        if (opt.isPresent() && opt.get().isPremium()) {
            // Premium: skip login/register entirely.
            plugin.getAuthManager().autoAuthenticate(player);
            Bukkit.getPluginManager().callEvent(new PremiumPlayerJoinEvent(player));
            Bukkit.getPluginManager().callEvent(new PlayerLoginEvent(player, PlayerLoginEvent.Cause.PREMIUM));
            plugin.getMessagesManager().send(player, "login.premium-auto", Map.of("player", player.getName()));
            return;
        }

        // Cracked player.
        String ip = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "unknown";
        boolean sessionValid = plugin.getSessionManager().hasValidSession(player.getUniqueId(), ip);

        boolean registered = opt.isPresent() && opt.get().isRegistered();

        if (sessionValid && registered) {
            plugin.getAuthManager().autoAuthenticate(player);
            Bukkit.getPluginManager().callEvent(new PlayerLoginEvent(player, PlayerLoginEvent.Cause.SESSION_RESTORE));
            plugin.getMessagesManager().send(player, "session.restored", Map.of("player", player.getName()));
            return;
        }

        Bukkit.getPluginManager().callEvent(new CrackedPlayerJoinEvent(player, !registered));
        plugin.getAuthManager().scheduleLoginTimeout(player);

        if (registered) {
            plugin.getMessagesManager().send(player, "login.prompt");
        } else {
            plugin.getMessagesManager().send(player, "register.prompt");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getAuthManager().cleanup(event.getPlayer().getUniqueId());
    }
}
