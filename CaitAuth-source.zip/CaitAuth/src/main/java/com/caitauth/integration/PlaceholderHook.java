package com.caitauth.integration;

import com.caitauth.CaitAuthPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/**
 * Exposes:
 *   %caitauth_authenticated%  -> "true" / "false"
 *   %caitauth_premium%        -> "true" / "false" (cached DB flag; async-fetched, may lag one tick on first use)
 *   %caitauth_registered%     -> "true" / "false"
 */
public class PlaceholderHook extends PlaceholderExpansion {

    private final CaitAuthPlugin plugin;

    public PlaceholderHook(CaitAuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() { return "caitauth"; }

    @Override
    public @NotNull String getAuthor() { return "CaitAuth"; }

    @Override
    public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";

        return switch (params.toLowerCase()) {
            case "authenticated" -> String.valueOf(
                    player.isOnline() && plugin.getAuthManager().isAuthenticated((org.bukkit.entity.Player) player));
            case "premium" -> {
                var cached = plugin.getDatabaseManager().getPlayer(player.getUniqueId()).getNow(java.util.Optional.empty());
                yield cached.map(d -> String.valueOf(d.isPremium())).orElse("false");
            }
            case "registered" -> {
                var cached = plugin.getDatabaseManager().getPlayer(player.getUniqueId()).getNow(java.util.Optional.empty());
                yield cached.map(d -> String.valueOf(d.isRegistered())).orElse("false");
            }
            default -> null;
        };
    }
}
