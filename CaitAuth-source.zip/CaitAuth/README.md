# CaitAuth

A hybrid premium (Mojang/Microsoft) + cracked authentication plugin for Paper 1.21.4 / Java 21.

## Building

This sandbox has no network access to Maven Central / the PaperMC repository, so the jar
could not be compiled here. On a machine with normal internet access:

```bash
cd CaitAuth
mvn clean package
```

The shaded jar will be at `target/CaitAuth-1.0.0.jar`. Drop it into your server's `plugins/` folder.

Requires: JDK 21, Maven 3.9+.

## How premium detection actually works (read this before deploying)

CaitAuth cannot re-implement Mojang's session server handshake itself — no plugin can, because
Mojang authentication happens at the network handshake layer, before any plugin code runs.
Instead, CaitAuth reads the *result* of authentication that Paper (or your proxy) already performed:

- **Standalone server, `online-mode: true`** in `server.properties`: Paper has already
  authenticated the player against Mojang by the time `AsyncPlayerPreLoginEvent` fires.
  CaitAuth trusts `Result.ALLOWED` at that point. This is the most reliable mode.

- **Behind Velocity with modern forwarding**: set `server.properties` `online-mode: false`,
  enable Velocity's `player-info-forwarding-mode: modern` with a shared `forwarding.secret`,
  and set the matching secret in Paper's `config/paper-global.yml` under
  `proxies.velocity.secret-key` (and `proxies.velocity.enabled: true`). Paper itself rejects
  unsigned/forged forwarding packets before your plugin ever sees the connection — CaitAuth's
  `proxy.forwarding-mode: VELOCITY_MODERN` setting is just an explicit opt-in flag so the
  plugin knows to trust the (already-validated) UUID it receives.

- **Behind BungeeCord with IP forwarding**: set `online-mode: false`, enable
  `bungeecord: true` in `spigot.yml`, and `ip_forward: true` on the proxy. Set
  `proxy.forwarding-mode: BUNGEE_LEGACY` in CaitAuth's config to match.

- **Floodgate/Geyser (Bedrock players)**: detected automatically via the Floodgate API if the
  Floodgate plugin is installed. Bedrock players are never asked to register/login through
  CaitAuth — Floodgate handles their identity linking separately.

**Important**: CaitAuth trusts your server/proxy network configuration. If you set
`proxy.forwarding-mode` but your proxy/Paper forwarding isn't actually configured correctly,
players could be misclassified. Always verify forwarding works (test with a known cracked
account) before relying on it in production.

## Configuration

See `config.yml` for all options (premium detection, timeouts, sessions, database, and which
protections are enabled) and `messages_en.yml` for all user-facing text — every message
supports `%placeholder%` substitution and `&`-style color codes.

## Commands

| Command | Description | Permission |
|---|---|---|
| `/register <password> <password>` | Register a cracked account | (none — self) |
| `/login <password>` | Log in for the session | (none — self) |
| `/changepassword <old> <new>` | Change your password | (none — self, must be logged in) |
| `/unregister <password>` | Remove your own account | (none — self) |
| `/unregister <player>` | Force-remove another account | `caitauth.unregister` |
| `/caitauth reload` | Reload config + messages | `caitauth.reload` |
| `/caitauth premium <player>` | Force-mark a player premium | `caitauth.admin` |
| `/caitauth cracked <player>` | Force-mark a player cracked | `caitauth.admin` |
| `/caitauth info <player>` | Show stored account info | `caitauth.admin` |

`caitauth.bypass` exempts a player from all protections (useful for staff/NPCs).

## API

```java
Bukkit.getPluginManager().registerEvents(new Listener() {
    @EventHandler
    public void onPremiumJoin(PremiumPlayerJoinEvent event) {
        // event.getPlayer() just skipped login entirely
    }

    @EventHandler
    public void onCrackedJoin(CrackedPlayerJoinEvent event) {
        // event.needsRegistration() tells you register vs login
    }

    @EventHandler
    public void onAuthLogin(com.caitauth.events.PlayerLoginEvent event) {
        // fires on password login, registration, premium auto-auth, or session restore
        // event.getCause() distinguishes which
    }
}, plugin);
```

Add CaitAuth as a dependency (`depend: [CaitAuth]` in your plugin.yml) to use these safely.

## Architecture notes

- All database I/O (`DatabaseManager`) runs on a dedicated 4-thread executor via
  `CompletableFuture` — never the main thread. Results are hopped back to the main thread with
  `Bukkit.getScheduler().runTask(...)` before touching any Bukkit API.
- All SQL uses `PreparedStatement` parameter binding exclusively; no string concatenation of
  user input anywhere in the codebase.
- Passwords are hashed with BCrypt (cost factor 12, random salt per password, via jBCrypt).
- SQLite uses a single-connection Hikari pool (SQLite only supports one writer at a time);
  MySQL uses a configurable pool size (default 10) suited for 500+ concurrent players.
